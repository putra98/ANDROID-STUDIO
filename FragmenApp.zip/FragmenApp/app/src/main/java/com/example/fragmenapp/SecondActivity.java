package com.example.fragmenapp;

import android.app.Activity;

public class SecondActivity extends Activity {
}
